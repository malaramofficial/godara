# मेरा पंचांग (Android)

पंचांग का HTML (`app/src/main/assets/index.html`) WebView में offline चलता है।
सारी गणना (तिथि, नक्षत्र, योग, करण, विंछुड़ो, चौघड़िया आदि) फ़ोन के अन्दर ही होती है।

## APK बनाना

**Android Studio से**
1. Android Studio में *Open* दबाकर यह `MeraPanchang` फ़ोल्डर खोलें (Gradle sync में कुछ देर लगेगी)।
2. *Build → Build Bundle(s) / APK(s) → Build APK(s)* दबाएँ।
3. APK यहाँ मिलेगा: `app/build/outputs/apk/debug/app-debug.apk`

**Terminal से** (JDK 17 या नया चाहिए, Android SDK ANDROID_HOME में हो)
```
./gradlew assembleDebug
```

फ़ोन पर APK install करते समय "अज्ञात स्रोत से install" की अनुमति देनी होगी।
Debug APK अपने आप sign होता है, निजी उपयोग के लिए यही काफ़ी है।

## जानने की बातें
- पैकेज का नाम `app.merapanchang` है, `app/build.gradle` में बदल सकते हैं।
- `INTERNET` अनुमति सिर्फ़ Google Fonts (Mukta, Tiro Devanagari) के लिए है। इण्टरनेट न हो तो सिस्टम फ़ॉण्ट से ही सब दिखता है।
- पंचांग अपडेट करना हो तो `assets/index.html` बदलकर फिर से build करें।
- यह project बनाने वाली जगह पर Android SDK उपलब्ध नहीं था, इसलिए इसे वहाँ compile नहीं किया जा सका।
  Java कोड और XML की सिर्फ़ syntax जाँच हुई है। Gradle sync में कोई त्रुटि आए तो वह त्रुटि भेज दें।
